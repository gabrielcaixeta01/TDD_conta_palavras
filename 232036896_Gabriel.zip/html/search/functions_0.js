var searchData=
[
  ['carregararquivo_0',['carregarArquivo',['../class_conta_palavras.html#a8e51ec73b97c70ed4a943851b889b89c',1,'ContaPalavras']]],
  ['contapalavras_1',['ContaPalavras',['../class_conta_palavras.html#a368e96d7a37f90ccea9c01ebd99e9479',1,'ContaPalavras']]]
];
