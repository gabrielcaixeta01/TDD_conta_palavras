var searchData=
[
  ['printpalavras_0',['printPalavras',['../class_conta_palavras.html#aed1ffafc84458fab0a84e0621da3ad2e',1,'ContaPalavras']]]
];
