var searchData=
[
  ['contapalavras_0',['ContaPalavras',['../class_conta_palavras.html',1,'']]]
];
