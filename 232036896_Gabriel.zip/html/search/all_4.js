var searchData=
[
  ['funcionalidades_0',['Funcionalidades',['../index.html#autotoc_md2',1,'']]]
];
