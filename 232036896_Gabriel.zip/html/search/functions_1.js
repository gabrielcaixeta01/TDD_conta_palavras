var searchData=
[
  ['getcontagem_0',['getContagem',['../class_conta_palavras.html#a652758cee7acfade5624357f10924d22',1,'ContaPalavras']]],
  ['getpalavra_1',['getPalavra',['../class_conta_palavras.html#aebea3bbd450ee4a6674bec0cc2a8e7f8',1,'ContaPalavras']]]
];
